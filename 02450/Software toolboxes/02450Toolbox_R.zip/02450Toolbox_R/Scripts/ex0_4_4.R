## exercise 0.4.4

# Extracting the elements from vectors is easy. Consider the
# following definition of x and the echoed results

x = c(rep(0,2),seq(from=0, to=3, length.out=6), rep(1, 3))
x[2:6] #  take out elements 2 through 5 (i.e. 6 not inclusive)
length(x) # return the length of x
# Try typing '?length'

x[length(x)] # take the last element of x

x[seq(from=2, by=2, to=length(x))] #return every other element of x starting from the 2nd

# Inserting numbers into vectors is also easy. Using the same
# definition of x and observe the results when typing
y = x

# Notice that we're inserting the same scalar value "pi" into all elements 
# that we index y with
y[seq(from=2, by=2, to=length(x))] = pi

# You can also try:
# y[seq(from=2, by=2, to=length(x))] = seq(from=2, by=2, to=10)

# Observe the results when indexing the vector y with
# y[1] and y[0]. Is y[0] defined?