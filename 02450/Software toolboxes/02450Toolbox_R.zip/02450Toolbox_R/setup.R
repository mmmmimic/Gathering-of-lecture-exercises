source("Tools/source_tools.R")
path = "Tools/"
sourceDir(path, exceptions=c("source_tools.R"))
#pathsep <- .Platform$file.sep # get file separator on operating system. We use the function file.path to ensure that filenames are compatible with the operating system instead of using .Platform$file.sep and the "paste" function.


