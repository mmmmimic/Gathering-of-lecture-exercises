% exercise 3.2.1

x = [-0.68; -2.11; 2.39; 0.26; 1.46; 1.33; 1.03; -0.41; -0.33; 0.47];

mean_x = mean(x);
std_x = std(x);
median_x = median(x);
range_x = range(x);

%% Display results
display(mean_x);
display(std_x);
display(median_x);
display(range_x);