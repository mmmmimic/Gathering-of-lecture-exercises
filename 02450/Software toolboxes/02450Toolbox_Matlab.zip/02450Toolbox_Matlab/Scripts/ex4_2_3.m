% exercise 4.2.3

%% Boxplot of each attribute
mfig('Boxplot'); clf;
boxplot(X, attributeNames);