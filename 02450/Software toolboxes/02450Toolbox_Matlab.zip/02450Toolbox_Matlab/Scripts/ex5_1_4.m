% exercise 5.1.4

% Define a new data object (a dragon) with the attributes given in the text
x = [0 2 1 2 1 1 1];

% Evaluate the classification tree for the new data object
T.predict(x)