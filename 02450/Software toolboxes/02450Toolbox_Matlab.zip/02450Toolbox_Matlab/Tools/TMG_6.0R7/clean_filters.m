function clean_filters()
%   CLEAN_FILTERS-cleans the directory containing the filters for any text
%       filters for any text garbagges left from previous tmg runnings.
%   
% Copyright 2011 Eugenia Maria Kontopoulou, Dimitrios Zeimpekis, Efstratios Gallopoulos

clean_filters_p;