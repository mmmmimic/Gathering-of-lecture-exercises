function idx=max_idx(Y)
% function to extract the column index of the max value for each row of Y

[val,idx]=max(Y,[],2);